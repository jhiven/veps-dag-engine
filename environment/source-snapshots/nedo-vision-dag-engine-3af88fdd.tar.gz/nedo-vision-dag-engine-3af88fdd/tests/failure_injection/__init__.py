"""Failure-injection tests package."""

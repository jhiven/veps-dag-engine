"""Static frame execution, frame instrumentation, and atomic plan publication."""

from __future__ import annotations

import time
from dataclasses import dataclass
from threading import Event, Lock

from nedo_vision_dag_engine.instrumentation import (
    FrameExecutionEvent,
    FrameStatus,
    NanosecondClock,
    RuntimeInstrumentation,
)
from nedo_vision_dag_engine.lifecycle import PlanLifecycleState
from nedo_vision_dag_engine.plan import ExecutionPlan, ExecutionStep, construct_inputs
from nedo_vision_dag_engine.processor import FrameContext
from nedo_vision_dag_engine.type_system import MISSING
from nedo_vision_dag_engine.workspace import Workspace, WorkspacePool

__all__ = [
    "FrameStatus",
    "FrameResult",
    "PlanSwap",
    "PublicationResult",
    "execute_frame",
    "PipelineExecutor",
]

# PublicationResult is a alias of PlanSwap for plan publication
type PublicationResult = PlanSwap


@dataclass(frozen=True, slots=True)
class FrameResult:
    frame_id: int
    plan_version: int
    status: FrameStatus
    executed_node_ids: tuple[str, ...]
    skipped_node_ids: tuple[str, ...]
    error: str | None = None


@dataclass(frozen=True, slots=True)
class PlanSwap:
    previous_plan: ExecutionPlan
    active_plan: ExecutionPlan


def _materialize_inputs(step: ExecutionStep, raw_inputs: dict[str, object]) -> object:
    input_schema = step.processor_ref.descriptor.input_schema
    if input_schema is object:
        return raw_inputs
    try:
        return input_schema(**raw_inputs)
    except TypeError as error:
        raise ValueError(
            f"failed to materialize inputs for node {step.node_id!r} into {input_schema!r}: {error}"
        ) from error


def execute_frame(
    plan: ExecutionPlan,
    frame_id: int,
    admitted_at_ns: int,
    workspace: Workspace,
) -> FrameResult:
    context = FrameContext(frame_id=frame_id, plan_version=plan.version, admitted_at_ns=admitted_at_ns)
    executed: list[str] = []
    skipped: list[str] = []

    for step in plan.steps:
        if not step.readiness_rule.is_ready(workspace):
            workspace.set(step.output_index, MISSING)
            skipped.append(step.node_id)
            continue

        try:
            raw_inputs = construct_inputs(step.input_bindings, workspace)
            materialized_inputs = _materialize_inputs(step, raw_inputs)
            output = step.processor_ref.process(materialized_inputs, context)
        except Exception as error:
            return FrameResult(
                frame_id=frame_id,
                plan_version=plan.version,
                status=FrameStatus.FAILED,
                executed_node_ids=tuple(executed),
                skipped_node_ids=tuple(skipped),
                error=repr(error),
            )

        workspace.set(step.output_index, output)
        executed.append(step.node_id)

    return FrameResult(
        frame_id=frame_id,
        plan_version=plan.version,
        status=FrameStatus.COMPLETED,
        executed_node_ids=tuple(executed),
        skipped_node_ids=tuple(skipped),
        error=None,
    )


class PipelineExecutor:
    """Serializes frame admission and plan publication.

    Two locks cooperate to separate plan-reference access from frame
    execution:

    - ``_plan_lock`` protects reads and writes of the ``_active_plan``
      reference.  Any caller that only needs to read the current plan
      (e.g. a reconfiguration controller capturing a snapshot for
      background compilation) acquires this lock alone and releases it
      in microseconds, even while a frame is mid-execution.

    - ``_execution_lock`` serializes frame admission and plan commits.
      It is held for the entire duration of frame execution and
      ``commit``/``commit_if_version``.  These operations acquire
      ``_plan_lock`` internally for the plan-reference read/write but
      release it before executing the frame body.

    Lock ordering is always ``_execution_lock`` then ``_plan_lock``,
    never reversed, which prevents deadlock.
    """

    __slots__ = (
        "_active_plan",
        "_clock",
        "_execution_lock",
        "_in_flight_lock",
        "_instrumentation",
        "_manager_token",
        "_next_frame_id",
        "_plan_inflight",
        "_plan_lifecycle",
        "_plan_lock",
        "_plan_quiescent_events",
        "_workspace_pool",
    )

    def __init__(
        self,
        initial_plan: ExecutionPlan,
        workspace_pool: WorkspacePool | None = None,
        instrumentation: RuntimeInstrumentation | None = None,
        clock: NanosecondClock = time.monotonic_ns,
    ) -> None:
        self._active_plan = initial_plan
        self._workspace_pool = workspace_pool if workspace_pool is not None else WorkspacePool()
        self._next_frame_id = 0
        self._plan_lock = Lock()
        self._execution_lock = Lock()
        self._in_flight_lock = Lock()
        self._manager_token: object | None = None
        self._clock = clock
        self._instrumentation = (
            instrumentation if instrumentation is not None else RuntimeInstrumentation(clock=clock)
        )
        self._plan_inflight: dict[int, int] = {}
        self._plan_quiescent_events: dict[int, Event] = {}
        self._plan_lifecycle: dict[int, PlanLifecycleState] = {
            initial_plan.version: PlanLifecycleState.ACTIVE,
        }

    @property
    def active_plan(self) -> ExecutionPlan:
        with self._plan_lock:
            return self._active_plan

    def active_plan_snapshot(self) -> ExecutionPlan:
        """Return the current active plan without holding the execution lock.

        This is safe for a reconfiguration controller to call while a
        frame is executing: the plan reference itself is immutable and
        the read is protected by ``_plan_lock`` alone.
        """
        with self._plan_lock:
            return self._active_plan

    def plan_lifecycle_state(self, plan_version: int) -> PlanLifecycleState | None:
        """Return the lifecycle state for a plan version, or None if unknown."""
        with self._plan_lock:
            return self._plan_lifecycle.get(plan_version)

    def wait_for_plan_quiescent(self, plan_version: int, timeout: float | None = None) -> bool:
        """Block until no frames are in-flight on the given plan version.

        Returns True if the plan became quiescent, False on timeout.
        Safe to call from any thread; does not acquire ``_execution_lock``.
        """
        event: Event | None = None
        with self._in_flight_lock:
            count = self._plan_inflight.get(plan_version, 0)
            if count == 0:
                self._plan_lifecycle[plan_version] = PlanLifecycleState.QUIESCENT
                return True
            event = self._plan_quiescent_events.setdefault(plan_version, Event())

        # Wait outside any lock so frames can complete
        assert event is not None
        result = event.wait(timeout=timeout)
        if result:
            with self._in_flight_lock:
                self._plan_lifecycle[plan_version] = PlanLifecycleState.QUIESCENT
        return result

    def _increment_inflight(self, plan_version: int) -> None:
        """Increment the in-flight counter for a plan version.

        Caller may hold ``_execution_lock`` or ``_plan_lock``; this method
        acquires ``_in_flight_lock`` internally.
        """
        with self._in_flight_lock:
            self._plan_inflight[plan_version] = self._plan_inflight.get(plan_version, 0) + 1

    def _decrement_inflight(self, plan_version: int) -> None:
        """Decrement the in-flight counter and signal waiters if it reaches zero.

        Acquires ``_in_flight_lock`` internally.  Safe to call while holding
        ``_execution_lock``.
        """
        with self._in_flight_lock:
            current = self._plan_inflight.get(plan_version, 0)
            if current <= 0:
                return  # defensive: should not happen
            new_count = current - 1
            if new_count == 0:
                del self._plan_inflight[plan_version]
                event = self._plan_quiescent_events.pop(plan_version, None)
                if event is not None:
                    event.set()
            else:
                self._plan_inflight[plan_version] = new_count

    def update_plan_lifecycle(self, plan_version: int, state: PlanLifecycleState) -> None:
        """Update the lifecycle state for a plan version."""
        with self._plan_lock:
            self._plan_lifecycle[plan_version] = state

    def claim_management(self, token: object) -> None:
        """Claim exclusive management of this executor."""
        with self._execution_lock:
            with self._plan_lock:
                if self._manager_token is not None:
                    raise RuntimeError("executor is already managed")
                self._manager_token = token

    def release_management(self, token: object) -> None:
        """Release exclusive management of this executor."""
        with self._execution_lock:
            with self._plan_lock:
                if self._manager_token is not token:
                    raise RuntimeError("invalid management token for release")
                self._manager_token = None

    def _require_unmanaged(self) -> None:
        if self._manager_token is not None:
            raise RuntimeError(
                "this executor is managed by a ReconfigurationController; "
                "use the controller's admit_frame() method instead."
            )

    @property
    def instrumentation(self) -> RuntimeInstrumentation:
        return self._instrumentation

    def commit(self, new_plan: ExecutionPlan) -> PlanSwap:
        """Public commit. Raises if managed by a controller."""
        with self._execution_lock:
            with self._plan_lock:
                self._require_unmanaged()
                return self._commit_plan_locked(new_plan)

    def commit_managed(self, token: object, new_plan: ExecutionPlan) -> PlanSwap:
        with self._execution_lock:
            with self._plan_lock:
                if token is not self._manager_token:
                    raise RuntimeError("invalid executor management token")
                return self._commit_plan_locked(new_plan)

    def commit_if_version(self, expected_version: int, new_plan: ExecutionPlan) -> PlanSwap | None:
        """Public conditional commit. Raises if managed by a controller."""
        with self._execution_lock:
            with self._plan_lock:
                self._require_unmanaged()
                if self._active_plan.version != expected_version:
                    return None
                return self._commit_plan_locked(new_plan)

    def commit_if_version_managed(
        self, token: object, expected_version: int, new_plan: ExecutionPlan
    ) -> PlanSwap | None:
        with self._execution_lock:
            with self._plan_lock:
                if token is not self._manager_token:
                    raise RuntimeError("invalid executor management token")
                if self._active_plan.version != expected_version:
                    return None
                return self._commit_plan_locked(new_plan)

    def admit_frame(self, admitted_at_ns: int, frame_id: int | None = None) -> FrameResult:
        """Public admission path. Raises if managed by a controller."""
        return self._admit_frame_locked(token=None, is_managed=False, admitted_at_ns=admitted_at_ns, frame_id=frame_id)

    def admit_frame_managed(
        self, token: object, admitted_at_ns: int, frame_id: int | None = None
    ) -> FrameResult:
        """Execute a frame when managed by a controller."""
        return self._admit_frame_locked(token=token, is_managed=True, admitted_at_ns=admitted_at_ns, frame_id=frame_id)

    def _admit_frame_locked(
        self, token: object | None, is_managed: bool, admitted_at_ns: int, frame_id: int | None = None
    ) -> FrameResult:
        """Core frame execution logic."""
        if admitted_at_ns < 0:
            raise ValueError("admitted_at_ns must be non-negative.")

        with self._execution_lock:
            with self._plan_lock:
                if is_managed:
                    if token is not self._manager_token:
                        raise RuntimeError("invalid executor management token")
                else:
                    self._require_unmanaged()
                plan = self._active_plan
                self._increment_inflight(plan.version)
            resolved_frame_id = self._next_frame_id if frame_id is None else frame_id
            if resolved_frame_id < 0:
                raise ValueError("frame_id must be non-negative.")
            self._next_frame_id = max(self._next_frame_id, resolved_frame_id + 1)

            workspace = self._workspace_pool.acquire(plan.output_slot_count)
            try:
                result = execute_frame(plan, resolved_frame_id, admitted_at_ns, workspace)
            finally:
                self._workspace_pool.release(workspace)
                self._decrement_inflight(plan.version)

            completed_at_ns = self._clock()
            self._instrumentation.record_frame(
                FrameExecutionEvent(
                    frame_id=result.frame_id,
                    plan_version=result.plan_version,
                    admission_timestamp_ns=admitted_at_ns,
                    completion_timestamp_ns=completed_at_ns,
                    executed_node_ids=result.executed_node_ids,
                    skipped_node_ids=result.skipped_node_ids,
                    status=result.status,
                    error=result.error,
                )
            )
            return result

    def snapshot_active_plan(self) -> ExecutionPlan:
        """Centralized accessor for taking a thread-safe snapshot of the active plan.

        Protected by ``_plan_lock``. Safe to call without holding ``_execution_lock``.
        """
        with self._plan_lock:
            return self._active_plan

    def publish_candidate_plan(self, new_plan: ExecutionPlan) -> PlanSwap:
        """Centralized publication linearization point for candidate plans.

        Linearization point:
            The plan reference atomic assignment ``self._active_plan = new_plan``
            is performed while holding ``_plan_lock``.
            Caller MUST hold ``_execution_lock`` before calling this method to prevent
            concurrent plan commits or frame execution race conditions. No external
            callbacks or processor code runs while holding these locks.
        """
        previous_plan = self._active_plan
        if new_plan.version <= previous_plan.version:
            raise ValueError(
                f"new plan version {new_plan.version} must be greater than active plan "
                f"version {previous_plan.version}."
            )
        self._active_plan = new_plan

        # Update plan lifecycle states
        self._plan_lifecycle[previous_plan.version] = PlanLifecycleState.SUPERSEDED
        self._plan_lifecycle[new_plan.version] = PlanLifecycleState.ACTIVE

        return PlanSwap(previous_plan=previous_plan, active_plan=new_plan)

    def _commit_plan_locked(self, new_plan: ExecutionPlan) -> PlanSwap:
        """Swap plan while holding ``_plan_lock``. Caller must also hold ``_execution_lock``."""
        return self.publish_candidate_plan(new_plan)
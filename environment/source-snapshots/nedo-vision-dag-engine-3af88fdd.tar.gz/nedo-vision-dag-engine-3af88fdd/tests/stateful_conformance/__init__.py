"""Stateful conformance tests package."""
